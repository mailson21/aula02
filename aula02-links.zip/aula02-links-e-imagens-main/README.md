# aula02-links-e-imagens
Criando uma landingpage simples com utilizando links e imagens na segunda aula de HTML no curso FULLSTACK DEVELOPER da escola iwtraining. 
